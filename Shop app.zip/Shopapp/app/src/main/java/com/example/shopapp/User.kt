package com.example.shopapp

class User(var login: String, var email: String, var pass: String) {
}